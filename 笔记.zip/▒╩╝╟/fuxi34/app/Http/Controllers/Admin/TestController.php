<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TestController extends Controller
{
    function fun1(){
        echo "11111111";
    }
    function fun2(){
        echo "22222222";
    }
}
