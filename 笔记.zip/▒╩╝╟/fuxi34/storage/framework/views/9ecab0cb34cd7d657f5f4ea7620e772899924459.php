<?php $__env->startSection('main2'); ?>
    1111111111111<br>
    11111111111111<br>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('head'); ?>
    22222222222222<br>
    222222222222<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Aaa.fuqin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>