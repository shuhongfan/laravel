<?php $__env->startSection('main2'); ?>
    xxxxxxxxx<br>
    yyyyyyyyyyy<br>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('head'); ?>
    aaaaaaaaa<br>
    bbbbbb<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main1'); ?>
    11111111111<br>
    22222222222<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Aaa.fuqin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>