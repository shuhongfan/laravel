<?php echo $__env->make('Aaa.toubu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<html>
  <h2>我在武汉很好的！</h2>
</html>