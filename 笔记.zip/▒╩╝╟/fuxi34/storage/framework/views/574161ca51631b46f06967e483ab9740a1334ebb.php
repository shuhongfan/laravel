<html>
  <h1>我爱你，中国!</h1>
  <?php echo $__env->yieldContent('head'); ?>

  <?php echo $__env->yieldContent('main1'); ?>

  <?php echo $__env->yieldContent('main2'); ?>
  <h2>中国是一个伟大的国家</h2>
</html>

