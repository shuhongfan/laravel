<html>
  <h1>我爱你，中国!</h1>
  @yield('head')

  @yield('main1')

  @yield('main2')
  <h2>中国是一个伟大的国家</h2>
</html>

