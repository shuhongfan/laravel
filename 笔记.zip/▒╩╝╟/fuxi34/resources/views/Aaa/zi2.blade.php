

@section('main2')
    1111111111111<br>
    11111111111111<br>
@endsection


@section('head')
    22222222222222<br>
    222222222222<br>
@endsection
@extends("Aaa.fuqin")