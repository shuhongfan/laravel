@extends("Aaa.fuqin")

@section('main2')
    xxxxxxxxx<br>
    yyyyyyyyyyy<br>
@endsection



@section('head')
    aaaaaaaaa<br>
    bbbbbb<br>
@endsection

@section('main1')
    11111111111<br>
    22222222222<br>
@endsection